package br.unipar;

import java.sql.*;
import java.util.Random;
import java.util.Scanner;
import java.nio.charset.Charset;

public class Main {

    private static final String url = "jdbc:postgresql://localhost:5432/postgres"; // Tira o localhost e coloca um ip de um banco real se tiver na tua máquina
    private static final String user = "postgres"; // Mesma coisa que o de cima, mas n usa ip
    private static final String password = "postgres"; // Mesma coisa que o de cima, mas a senha

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        createTableUsers();
        System.out.println("Choose an operation: 1. Insert 2. Update 3. List 4. Delete");
        int choice = scanner.nextInt();
        scanner.nextLine();

        // Cara eu vou ser sincero, n testei os outros métodos, só o insert...

        switch (choice) {
            case 1:
                insertUserFromInput(scanner);
                break;
            case 2:
                updateUserFromInput(scanner);
                break;
            case 3:
                listUsers();
                break;
            case 4:
                deleteUserFromInput(scanner);
                break;
            default:
                System.out.println("Invalid choice, ANOTHER ONE <3");
        }

        scanner.close();
    }

    public static Connection connection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    public static void createTableUsers() {
        try (Connection connection = connection();
             Statement statement = connection.createStatement()) {

            String sql = "CREATE TABLE IF NOT EXISTS users ( "
                    + "id SERIAL PRIMARY KEY, "
                    + "username VARCHAR(255) UNIQUE NOT NULL, "
                    + "password VARCHAR(255) UNIQUE NOT NULL, "
                    + "name VARCHAR(255) UNIQUE NOT NULL, "
                    + "birthday DATE NOT NULL)";

            statement.executeUpdate(sql);
            System.out.println("Create table users successfully!");

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
    }

    public static void insertUserFromInput(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter birthday (YYYY-MM-DD): ");
        String birthday = scanner.nextLine();

        insertUser(username, password, name, birthday);
    }

    public static void insertUser(String username, String password, String name, String birthday) {
        String sql = "INSERT INTO users (username, password, name, birthday) VALUES (?, ?, ?, ?)";
        try (Connection connection = connection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, username);
            statement.setString(2, password);
            statement.setString(3, name);
            statement.setDate(4, Date.valueOf(birthday));
            statement.executeUpdate();
            System.out.println("Insert into users successfully!");

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
    }

    public static void updateUserFromInput(Scanner scanner) {
        System.out.print("Enter user ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new username: ");
        String username = scanner.nextLine();
        System.out.print("Enter new password: ");
        String password = scanner.nextLine();
        System.out.print("Enter new name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new birthday (YYYY-MM-DD): ");
        String birthday = scanner.nextLine();

        updateUser(id, username, password, name, birthday);
    }

    public static void updateUser(int id, String username, String password, String name, String birthday) {
        String sql = "UPDATE users SET username = ?, password = ?, name = ?, birthday = ? WHERE id = ?";
        try (Connection connection = connection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, username);
            statement.setString(2, password);
            statement.setString(3, name);
            statement.setDate(4, Date.valueOf(birthday));
            statement.setInt(5, id);
            statement.executeUpdate();
            System.out.println("Update user successfully!");

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
    }

    public static void listUsers() {
        String sql = "SELECT * FROM users";
        try (Connection connection = connection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String name = resultSet.getString("name");
                Date birthday = resultSet.getDate("birthday");
                System.out.printf("ID: %d, Username: %s, Password: %s, Name: %s, Birthday: %s%n", id, username, password, name, birthday);
            }

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
    }

    public static void deleteUserFromInput(Scanner scanner) {
        System.out.print("Enter user ID to delete: ");
        int id = scanner.nextInt();
        deleteUser(id);
    }

    public static void deleteUser(int id) {
        String sql = "DELETE FROM users WHERE id = ?";
        try (Connection connection = connection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            statement.executeUpdate();
            System.out.println("Delete user successfully!");

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
    }

    public static void testInsertUser() {
        insertUser("testUser1", "testPass1", "Test User 1", "2000-01-01");
    }

    public static void testUpdateUser() {
        insertUser("testUser2", "testPass2", "Test User 2", "2001-01-01");
        listUsers();
        updateUser(2, "updatedUser2", "updatedPass2", "Updated User 2", "2001-02-02");
    }

    public static void testDeleteUser() {
        insertUser("testUser3", "testPass3", "Test User 3", "2002-01-01");
        listUsers();
        deleteUser(3);
    }

    public static void testListUsers() {
        listUsers();
    }
}